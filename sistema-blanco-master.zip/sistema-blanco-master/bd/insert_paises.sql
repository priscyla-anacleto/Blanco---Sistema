insert into paises (codpais, pais, ddi, sigla) values (0, 'BRASIL', '+55', 'BR');
insert into paises (codpais, pais, ddi, sigla) values (0, 'PARAGUAI', '+595', 'PY');
insert into paises (codpais, pais, ddi, sigla) values (0, 'ARGENTINA', '+56', 'AR');